package bjtu.ebookshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBookShopApplication {

    public static void main(String[] args) {
        SpringApplication.run(EBookShopApplication.class, args);
    }

}
