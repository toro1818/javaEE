package bjtu.edu.ebookshoprestful.repository;

import bjtu.edu.ebookshoprestful.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer> {
}
