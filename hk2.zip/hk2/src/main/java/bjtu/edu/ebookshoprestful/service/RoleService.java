package bjtu.edu.ebookshoprestful.service;

import bjtu.edu.ebookshoprestful.entity.Role;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleService implements IRoleService{
    @Override
    public List<Role> findALL() {
        return null;
    }

    @Override
    public Role findOne(Integer id) {
        return null;
    }

    @Override
    public Role insert(Role b) {
        return null;
    }

    @Override
    public Role update(Role b) {
        return null;
    }

    @Override
    public void delete(Integer id) {

    }
}
