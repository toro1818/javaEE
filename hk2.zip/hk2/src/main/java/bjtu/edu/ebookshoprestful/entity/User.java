package bjtu.edu.ebookshoprestful.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "users")
@Data
public class User {
    @Id
    @GeneratedValue
    @Column(name = "ID")
    private long id;

    @Column(name = "username",unique = true)
    private String username;

    @Column(name = "password")
    private String password;

}
